import DashboardIcon from "./dashboard.png"
import CalendarIcon from "./calendar.png"
import MealIcon from "./meal.png"
import AnalysisIcon from "./analysis.png"
import SettingsIcon from "./settings.png"


export { DashboardIcon, CalendarIcon, MealIcon, AnalysisIcon, SettingsIcon};