const SchedulePreferences = ()=>{
    return(
        <div className="min-w-60 w-1/3 max-w-1/3 rounded-2xl bg-gray-500 flex flex-col pt-7 pb-4 pl-5 pr-5 mt-6">
            <h3 className="mb-8 text-white">Plan i preferencje</h3>
        </div>
    )
}

export default SchedulePreferences;