const Nutrition = ()=>{
    return(
    <>
        <p>Nutrition</p>
    </>)
}

export default Nutrition;