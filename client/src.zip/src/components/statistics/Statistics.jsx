const Statistics = ()=>{
    return(
        <>
            <p>Statistics</p>
        </>
    )
}

export default Statistics;