import {DashboardIcon, CalendarIcon, MealIcon, AnalysisIcon, SettingsIcon } from "../../assets/icons";
import MenuOption from "../menu/MenuOption";

const menuItems = [
    {title: "Ekran główny", url: "", iconUrl: DashboardIcon},
    {title: "Kalendarz", url: "calendar", iconUrl: CalendarIcon},
    {title: "Żywienie", url: "nutrition", iconUrl: MealIcon},
    {title: "Statystyki", url: "statistics", iconUrl: AnalysisIcon},
    {title: "Ustawienia", url: "settings", iconUrl: SettingsIcon},
];

function Sidebar({selectedOption}){

    return(
        <>
            <nav className="fixed left-0 top-0 w-fit lg:w-70 lg:max-w-1/4 flex flex-col gap-5 min-h-screen p-2 pt-5 bg-gray-800 ring-2 ring-gray-900">
                {menuItems.map((item, index) => (
                    <MenuOption key={index} title={item.title} url={item.url} iconUrl={item.iconUrl} isActive={selectedOption === item.url}/>
                ))}
            </nav>
        </>
    );
}

export default Sidebar