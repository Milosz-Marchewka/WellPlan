const StyledColorInput = ()=>{

}

export default StyledColorInput;